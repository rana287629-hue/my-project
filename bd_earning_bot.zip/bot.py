
import os
import sqlite3
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters
)

TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
DB = os.getenv("DB_PATH", "bot.db")

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

def db():
    return sqlite3.connect(DB)

def init_db():
    con = db()
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY, username TEXT, balance REAL DEFAULT 0,
        referrals INTEGER DEFAULT 0, referred_by INTEGER
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS tasks(
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
        reward REAL NOT NULL, url TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS completed(
        user_id INTEGER, task_id INTEGER, UNIQUE(user_id, task_id)
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS withdrawals(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        amount REAL, method TEXT, account TEXT, status TEXT DEFAULT 'pending'
    )""")
    con.commit(); con.close()

def ensure_user(user):
    con = db(); cur = con.cursor()
    cur.execute("SELECT id FROM users WHERE id=?", (user.id,))
    if not cur.fetchone():
        cur.execute("INSERT INTO users(id,username) VALUES(?,?)",
                    (user.id, user.username or ""))
    else:
        cur.execute("UPDATE users SET username=? WHERE id=?",
                    (user.username or "", user.id))
    con.commit(); con.close()

def menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 Tasks", callback_data="tasks"),
         InlineKeyboardButton("💰 Balance", callback_data="balance")],
        [InlineKeyboardButton("👥 Refer", callback_data="refer"),
         InlineKeyboardButton("💸 Withdraw", callback_data="withdraw")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help")]
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    # Referral: /start REFERRER_ID
    if context.args:
        try:
            ref = int(context.args[0])
            if ref != update.effective_user.id:
                con=db(); cur=con.cursor()
                cur.execute("SELECT referred_by FROM users WHERE id=?", (update.effective_user.id,))
                row=cur.fetchone()
                if row and row[0] is None:
                    cur.execute("UPDATE users SET referred_by=? WHERE id=?",
                                (ref, update.effective_user.id))
                    cur.execute("UPDATE users SET referrals=referrals+1, balance=balance+1 WHERE id=?",
                                (ref,))
                con.commit(); con.close()
        except ValueError:
            pass
    await update.message.reply_text(
        "স্বাগতম BD Earning-এ!\\n\\nবৈধ কাজ সম্পন্ন করে reward পেতে Tasks দেখুন।",
        reply_markup=menu()
    )

async def tasks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid=update.effective_user.id
    con=db(); cur=con.cursor()
    cur.execute("""SELECT t.id,t.title,t.reward,t.url FROM tasks t
                   LEFT JOIN completed c ON c.task_id=t.id AND c.user_id=?
                   WHERE c.user_id IS NULL ORDER BY t.id DESC""",(uid,))
    rows=cur.fetchall(); con.close()
    if not rows:
        await send(update, "এই মুহূর্তে কোনো নতুন Task নেই।")
        return
    buttons=[]
    text="📋 Available Tasks\\n\\n"
    for tid,title,reward,url in rows:
        text += f"#{tid} {title} — ৳{reward:.2f}\\n"
        buttons.append([InlineKeyboardButton(
            f"#{tid} • ৳{reward:.2f}", callback_data=f"task:{tid}")])
    await send(update, text, InlineKeyboardMarkup(buttons))

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    con=db(); cur=con.cursor()
    cur.execute("SELECT balance,referrals FROM users WHERE id=?", (update.effective_user.id,))
    b,r=cur.fetchone(); con.close()
    await send(update, f"💰 Balance: ৳{b:.2f}\\n👥 Referrals: {r}")

async def refer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    me=update.effective_user
    await send(update,
        f"👥 আপনার Referral Link:\\n"
        f"https://t.me/{context.bot.username}?start={me.id}\\n\\n"
        f"রেফার করা ইউজার যোগ দিলে demo reward হিসেবে ৳1 যোগ হবে। "
        f"বাস্তবে reward দেওয়ার আগে আপনার offer/advertiser-এর নিয়ম নিশ্চিত করুন।")

async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await send(update,
        "💸 Withdrawal request দিতে এই ফরম্যাটে লিখুন:\\n"
        "/withdraw 50 bkash 01XXXXXXXXX\\n\\n"
        "ন্যূনতম amount আপনার ব্যবসার নিয়ম অনুযায়ী পরিবর্তন করুন।")

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await send(update,
        "ℹ️ Help\\n\\n/tasks — কাজ\\n/balance — ব্যালেন্স\\n"
        "/refer — referral link\\n/withdraw — withdrawal নিয়ম")

async def send(update, text, markup=None):
    if update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=markup)
    else:
        await update.message.reply_text(text, reply_markup=markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await q.answer()
    if q.data=="tasks": await tasks(update,context)
    elif q.data=="balance": await balance(update,context)
    elif q.data=="refer": await refer(update,context)
    elif q.data=="withdraw": await withdraw(update,context)
    elif q.data=="help": await help_cmd(update,context)
    elif q.data.startswith("task:"):
        tid=int(q.data.split(":")[1]); uid=q.from_user.id
        con=db(); cur=con.cursor()
        cur.execute("SELECT title,reward,url FROM tasks WHERE id=?",(tid,))
        row=cur.fetchone()
        if not row:
            con.close(); return await q.message.reply_text("Task পাওয়া যায়নি।")
        title,reward,url=row
        cur.execute("SELECT 1 FROM completed WHERE user_id=? AND task_id=?",(uid,tid))
        if cur.fetchone():
            con.close(); return await q.message.reply_text("এই Task আগে সম্পন্ন করেছেন।")
        # IMPORTANT: This demo credits reward when user presses the button.
        # For real advertiser tasks, verify completion with the advertiser before crediting.
        cur.execute("INSERT INTO completed(user_id,task_id) VALUES(?,?)",(uid,tid))
        cur.execute("UPDATE users SET balance=balance+? WHERE id=?",(reward,uid))
        con.commit(); con.close()
        msg=f"✅ Task completed (demo)\\nReward: ৳{reward:.2f}"
        if url: msg += f"\\nTask link: {url}"
        await q.message.reply_text(msg)

async def withdraw_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ensure_user(update.effective_user)
    if len(context.args) != 3:
        return await update.message.reply_text(
            "ফরম্যাট: /withdraw 50 bkash 01XXXXXXXXX")
    try: amount=float(context.args[0])
    except ValueError:
        return await update.message.reply_text("Amount সঠিকভাবে দিন।")
    method=context.args[1].lower(); account=context.args[2]
    if amount <= 0: return await update.message.reply_text("Amount 0-এর বেশি হতে হবে।")
    con=db(); cur=con.cursor()
    cur.execute("SELECT balance FROM users WHERE id=?",(update.effective_user.id,))
    bal=cur.fetchone()[0]
    if amount > bal:
        con.close(); return await update.message.reply_text("আপনার ব্যালেন্স যথেষ্ট নয়।")
    cur.execute("""UPDATE users SET balance=balance-? WHERE id=?""",
                (amount,update.effective_user.id))
    cur.execute("""INSERT INTO withdrawals(user_id,amount,method,account)
                   VALUES(?,?,?,?)""",(update.effective_user.id,amount,method,account))
    wid=cur.lastrowid; con.commit(); con.close()
    await update.message.reply_text(f"✅ Withdrawal request #{wid} জমা হয়েছে।")
    if ADMIN_ID:
        await context.bot.send_message(
            ADMIN_ID,
            f"💸 New withdrawal #{wid}\\nUser: {update.effective_user.id}\\n"
            f"Amount: ৳{amount:.2f}\\nMethod: {method}\\nAccount: {account}")

async def addtask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID: return
    if len(context.args) < 2:
        return await update.message.reply_text(
            "ফরম্যাট: /addtask Title|reward|url")
    raw=" ".join(context.args)
    parts=[p.strip() for p in raw.split("|")]
    if len(parts)<2: return await update.message.reply_text("Title|reward|url ফরম্যাট ব্যবহার করুন।")
    title=parts[0]
    try: reward=float(parts[1])
    except ValueError: return await update.message.reply_text("Reward সংখ্যা হতে হবে।")
    url=parts[2] if len(parts)>2 else ""
    con=db(); cur=con.cursor()
    cur.execute("INSERT INTO tasks(title,reward,url) VALUES(?,?,?)",(title,reward,url))
    con.commit(); tid=cur.lastrowid; con.close()
    await update.message.reply_text(f"✅ Task #{tid} যোগ হয়েছে।")

async def withdrawals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID: return
    con=db(); cur=con.cursor()
    cur.execute("""SELECT id,user_id,amount,method,account,status
                   FROM withdrawals ORDER BY id DESC LIMIT 20""")
    rows=cur.fetchall(); con.close()
    if not rows: return await update.message.reply_text("কোনো withdrawal নেই।")
    text="💸 Withdrawals\\n\\n"
    for r in rows:
        text += f"#{r[0]} user={r[1]} ৳{r[2]:.2f} {r[3]} {r[4]} [{r[5]}]\\n"
    await update.message.reply_text(text)

def main():
    if not TOKEN or not ADMIN_ID:
        raise SystemExit("BOT_TOKEN and ADMIN_ID must be set.")
    init_db()
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("tasks", tasks))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("refer", refer))
    app.add_handler(CommandHandler("withdraw", withdraw_cmd))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("addtask", addtask))
    app.add_handler(CommandHandler("withdrawals", withdrawals))
    app.add_handler(CallbackQueryHandler(button))
    app.run_polling()

if __name__=="__main__":
    main()
