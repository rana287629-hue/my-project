# BD Earning Telegram Bot

এটি একটি starter bot: Tasks, Balance, Referral এবং Withdrawal request আছে।

## 1) BotFather
আপনার নতুন Bot Token `.env`-এ বসান। Token কাউকে পাঠাবেন না।

## 2) নিজের Telegram ID
নিজের numeric Telegram user ID বের করে `ADMIN_ID`-তে বসান।

## 3) Install
```bash
pip install -r requirements.txt
```

## 4) Run
Linux/hosting:
```bash
export BOT_TOKEN="আপনার_TOKEN"
export ADMIN_ID="আপনার_ID"
python bot.py
```

Windows PowerShell:
```powershell
$env:BOT_TOKEN="আপনার_TOKEN"
$env:ADMIN_ID="আপনার_ID"
python bot.py
```

## Admin
`/addtask Title|reward|url`
উদাহরণ:
`/addtask Facebook page visit|2|https://example.com`

`/withdrawals`

### গুরুত্বপূর্ণ
এই starter version-এ Task button চাপলে demo হিসেবে reward যোগ হয়। বাস্তব বিজ্ঞাপন/affiliate task-এ advertiser-এর API/postback দিয়ে completion যাচাই না করে টাকা credit করবেন না। অন্যথায় fraud/chargeback হতে পারে।

Withdrawal এখন request হিসেবে database-এ জমা হয়; বাস্তব bKash/Nagad payout API আলাদাভাবে যুক্ত করতে হবে।
